﻿Console.WriteLine("Atribuindo valores para bool e char");

//boolean armazena true ou false
bool ativo = true;
System.Boolean inativo = false;

Console.WriteLine(ativo);
Console.WriteLine(inativo);

//um booleano é resultado das operações
//de comparação
Console.WriteLine(10 == 15);
Console.WriteLine(10 == 10);

int x = 10;
int y = 15;
Console.WriteLine(x > y);

//O tipo char pode expressar o caractere ou o valor unicode
char letra1 = 'A';
char letra2 = '\u0041';

Console.WriteLine(letra1);
Console.WriteLine(letra2);

Console.ReadLine();

